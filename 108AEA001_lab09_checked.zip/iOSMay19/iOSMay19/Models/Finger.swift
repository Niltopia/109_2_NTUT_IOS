//
//  Finger.swift
//  iOSMay19
//
//  Created by Vesper Lee on 2021/5/19.
//

import Foundation

struct Finger {
    let suit: Suit
    
    enum Suit: String, CaseIterable {
        case rock = "👊"
        case paper = "🖐"
        case scissors = "✌️"
    }
    
}
