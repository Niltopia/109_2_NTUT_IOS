//
//  GameResult.swift
//  iOSMay19
//
//  Created by Vesper Lee on 2021/5/19.
//

import Foundation
enum GameResult {
    case win
    case lose
    case tie
    case defaultR
}
