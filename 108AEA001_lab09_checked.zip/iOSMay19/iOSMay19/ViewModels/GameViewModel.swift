//
//  GameViewModel.swift
//  iOSMay19
//
//  Created by Vesper Lee on 2021/5/19.
//

import Foundation
import GameplayKit

class GameViewModel: ObservableObject {
    @Published var playerFinger: Finger?
    @Published var computerFinger: Finger?
    @Published var result: GameResult?
    
    var fingers: [Finger] = {
        var fingers = [Finger]()
        for suit in Finger.Suit.allCases {
            let finger = Finger(suit: suit)
            fingers.append(finger)
        }
        return fingers
    }()
    
    func play() {
        fingers.shuffle()
        playerFinger = fingers[0]
        computerFinger = fingers[1]
        result = checkResult()
    }
    
    func checkResult() ->  GameResult {
        if playerFinger?.suit.rawValue == "👊" {
            if computerFinger?.suit.rawValue == "👊"{
                return .tie
            }
            else if computerFinger?.suit.rawValue == "🖐"{
                return .lose
            }
            else if computerFinger?.suit.rawValue == "✌️"{
                return .win
            }
            
        }
        else if playerFinger?.suit.rawValue == "🖐" {
            if computerFinger?.suit.rawValue == "🖐"{
                return .tie
            }
            else if computerFinger?.suit.rawValue == "✌️"{
                return .lose
            }
            else if computerFinger?.suit.rawValue == "👊"{
                return .win
            }
            
        }
        else if playerFinger?.suit.rawValue == "✌️" {
            if computerFinger?.suit.rawValue == "👊"{
                return .lose
            }
            else if computerFinger?.suit.rawValue == "🖐"{
                return .win
            }
            else if computerFinger?.suit.rawValue == "✌️"{
                return .tie
            }
        }
        return .defaultR
    }
}
