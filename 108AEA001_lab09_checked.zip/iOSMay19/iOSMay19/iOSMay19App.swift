//
//  iOSMay19App.swift
//  iOSMay19
//
//  Created by Vesper Lee on 2021/5/19.
//

import SwiftUI

@main
struct iOSMay19App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
