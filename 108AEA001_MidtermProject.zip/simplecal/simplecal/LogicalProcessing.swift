//
//  LogicalProcessing.swift
//  simplecal
//
//  Created by Vesper Lee on 2021/4/20.
//

import Foundation

class CalLogic{
    var first_number:String = "0"
    var second_number:String = "0"
    var history:String = "0"
    var calculate_operator:Int = 0
    
    func formatText(input:String) -> String {
        var output:String = "";
        let convert_input:Double = Double(input)!
        if convert_input.truncatingRemainder(dividingBy: 1) == 0
        {
            output = String(format: "%.0f", convert_input)
        }else{
            output = String(convert_input)
        }
        
        return output
    }
    

    
    func calculate(first_number_parm:String,second_number_parm:String,calculate_operator_parm:Int)->(history:String, first_number:String)?{
        first_number = first_number_parm
        second_number = second_number_parm
        calculate_operator = calculate_operator_parm
        if(calculate_operator==0){
            if second_number == "0" {
                history = formatText(input: first_number) + " ="
            }else{
                history = formatText(input: second_number) + " ="
                first_number = second_number
            }
        }
        else if(calculate_operator==1){
            history = formatText(input:first_number) + " + " + formatText(input:second_number) + " ="
            let result:Double = Double(first_number)! + Double(second_number)!
            first_number = String(result)
        }
        else if(calculate_operator==2){
            history = formatText(input:first_number) + " － " + formatText(input:second_number) + " ="
            let result:Double = Double(first_number)! - Double(second_number)!
            first_number = String(result)
        }
        else if(calculate_operator==3){
            history = formatText(input:first_number) + " × " + formatText(input:second_number) + " ="
            let result:Double = Double(first_number)! * Double(second_number)!
            first_number = String(result)
        }
        else if(calculate_operator==4){
            history = formatText(input:first_number) + " ÷ " + formatText(input:second_number) + " ="
            let result:Double
            if Double(second_number) != 0 {
                result = Double(first_number)! / Double(second_number)!
            }else{
                result = 0
            }
            first_number = String(result)
            
        }
        return (history,first_number)
    }
}
