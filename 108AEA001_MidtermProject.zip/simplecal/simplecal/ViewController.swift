//
//  ViewController.swift
//  simplecal
//
//  Created by Vesper Lee on 2021/3/8.
//

import UIKit
class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    var first_number:String = "0"
    var second_number:String = "0"
    var result_for_percent:String = "0"
    var text_var:String = "0"
    var calculate_operator:Int = 0
    var calLogic:CalLogic=CalLogic()
    @IBOutlet weak var text_field: UILabel!
    @IBOutlet weak var result_label: UILabel!
    @IBOutlet var number_collection: [UIButton]!
    
    func showText(text:String){
        text_field.text = text;
    }
    
    func showResult(result:String){
        result_label.text = calLogic.formatText(input: result);
    }
    
    func operatorSwitch(input:Int){
        let operator_parm:Int = input
        if second_number != "0" {
            if calculate_operator == 0 {
                first_number = second_number
                second_number = "0"
            }
        }
        calculate_operator = operator_parm
    }
    
    @IBAction func clearAll(_ sender: UIButton) {
        first_number = "0"
        second_number = "0"
        text_var = "0"
        calculate_operator = 0
        showText(text: "")
        showResult(result: "0")
    }
    
    @IBAction func button_point(_ sender: UIButton) {
        if !second_number.contains(".") {
            if second_number == "0" {
                second_number = "0."
            }else{
                second_number += "."
            }
        }
        showResult(result: second_number)
    }
    
    @IBAction func button_percent(_ sender: UIButton) {
        if Double(first_number) == 0
        {
            second_number = String(Double(second_number)! / 100)
            showResult(result: second_number)
        }else{
            print(first_number)
            let result = Double(result_for_percent)! / 100
            showText(text: "")
            showResult(result: String(result))
        }
    }
    @IBAction func button_equal(_ sender: UIButton) {
        if let result = calLogic.calculate(first_number_parm: first_number, second_number_parm: second_number, calculate_operator_parm: calculate_operator) {
            calculate_operator = 0
            second_number = "0"
            result_for_percent=result.first_number
            showResult(result: result.first_number)
            showText(text: result.history)
        }
        
    }
    
    @IBAction func number_action(_ sender: UIButton) {
        let number:Int = number_collection.firstIndex(of: sender)!
        if second_number == "0" {
            second_number = String(number)
        }else{
            second_number += String(number)
        }
        
        showResult(result: second_number)
    }
    
    @IBAction func button_plus(_ sender: UIButton) {
       operatorSwitch(input:1)
    }
    @IBAction func button_minus(_ sender: UIButton) {
        operatorSwitch(input:2)
    }
    @IBAction func button_muptiply(_ sender: UIButton) {
        operatorSwitch(input:3)
    }
    @IBAction func button_divide(_ sender: UIButton) {
        operatorSwitch(input:4)
    }
    
    @IBAction func button_pn(_ sender: UIButton) {
        if second_number != "0" {
            text_var = "±( \(second_number) ) ="
            showText(text: text_var)
            
            let result:Double = -Double(second_number)!
            second_number = String(result)
            showResult(result: second_number)
            
        }else if first_number != "0"{
            text_var = "±( \(first_number) ) ="
            showText(text: text_var)
            
            let result:Double = -Double(first_number)!
            first_number = String(result)
            showResult(result: first_number)
        }
    }
}

