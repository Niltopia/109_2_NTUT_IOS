//
//  swifttestApp.swift
//  swifttest
//
//  Created by Vesper Lee on 2021/5/3.
//

import SwiftUI

@main
struct swifttestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
