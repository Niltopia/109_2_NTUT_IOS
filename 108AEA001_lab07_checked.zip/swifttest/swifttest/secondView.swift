//
//  secondView.swift
//  swifttest
//
//  Created by Vesper Lee on 2021/5/5.
//

import SwiftUI

struct secondView: View {
    @Binding var showThirdPage: Bool
    var body: some View {
        ZStack{
            Color.black.edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            viewBody1()
        }.overlay(Button(action: {showThirdPage=false}, label: {
                Image(systemName: "xmark.circle.fill").resizable().frame(width: 50, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/).padding(20)
        }),alignment: .topTrailing)
    }
}

struct secondView_Previews: PreviewProvider {
    static var previews: some View {
        secondView(showThirdPage: .constant(true))
    }
}


struct dataView1 {
   var str: String
   var img: String
}

struct viewBody1: View {
    var body: some View {
    let data =  [
        dataView1(str: "XM Anomaly（XM 異常）[註 1]，XM 濃度非常高的時期，兩個陣營的玩家爭奪一組 Portal 的控制權，為自己的隊伍贏得分數。異常事件通常發生在幾個星期之中，不同的事件發生在世界各地的主要城市。異常位置被分為兩類：主要站點和衛星站點。Niantic 員工和 Ingress 故事人物經常出席主要站點。主站點授予的分數通常比衛星站點多。XM 異常事件的結果往往影響 Ingress 背景故事的未來事件。", img: "xma"),
     ]
        Text("社群互動")
            .font(Font.system(size: 40))
            .foregroundColor(Color.white)
            .offset(y: -300)
        ForEach(data, id: \.str) { dataView in
           
            Image(dataView.img).resizable().frame(width: 400, height: 300)
                .offset(y: -100)
            Text(dataView.str).foregroundColor(Color.white)
                .padding(.horizontal)
                .offset(y: 170)
        }
    }
}

