//
//  ContentView.swift
//  swifttest
//
//  Created by Vesper Lee on 2021/5/3.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Color.black
            .ignoresSafeArea(.all, edges: [.top, .bottom])

.overlay(        VStack{
                    
                    Text("Ingress Prime")
                        .font(Font.system(size: 40))
                        .foregroundColor(Color.white)
                        .multilineTextAlignment(.leading)
                        .offset(y: -140)
                    circleImageView(name:"INGRESS")
                        .offset(y: -100)
                    GoLoginView()
                })

    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct circleImageView: View {
    let name:String
    var body: some View {
        Image(name)
            .resizable()
            .scaledToFill()
            .frame(width: 200, height: 200)
            .clipShape(Circle())
            .shadow(radius: 20)
    }
}

struct GoLoginView: View {
    @State private var showSecondPage = false
    @State private var showThirdPage = false
    var body: some View {
        Button(action: {
            showSecondPage=true
        }, label: {
            Text("故事背景")
                .foregroundColor(.white)
        }).sheet(isPresented: $showSecondPage, content: {
            LoginView(showSecondPage: $showSecondPage)
        }).padding()
        .overlay(
            RoundedRectangle(cornerRadius: 30)
                .stroke(Color.white, lineWidth: 2)
        )
        
        Button(action: {
            showThirdPage=true
        }, label: {
            Text("社群互動")
                .foregroundColor(.white)
        }).sheet(isPresented: $showThirdPage, content: {
            secondView(showThirdPage: $showThirdPage)
        }).padding()
        .overlay(
            RoundedRectangle(cornerRadius: 30)
                .stroke(Color.white, lineWidth: 2)
        )
        
        
    }
}
