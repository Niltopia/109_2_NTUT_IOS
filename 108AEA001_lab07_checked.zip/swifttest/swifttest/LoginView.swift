//
//  LoginView.swift
//  swifttest
//
//  Created by Vesper Lee on 2021/5/3.
//

import SwiftUI

struct LoginView: View {
    @Binding var showSecondPage: Bool
    var body: some View {
        ZStack{
            Color.black.edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            viewBody()
        }.overlay(Button(action: {showSecondPage=false}, label: {
                Image(systemName: "xmark.circle.fill").resizable().frame(width: 50, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/).padding(20)
        }),alignment: .topTrailing)
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView(showSecondPage: .constant(true))
    }
}

struct dataView {
   var str: String
   var img: String
}

struct viewBody: View {
    var body: some View {
    let data =  [
        dataView(str: "遊戲的故事背景是一群歐洲科學家偶然發現某種神秘的能量XM（Exotic Matter），這一能量的來源和用途無人知曉，研究人員認為可以開發並善用這能量，但另一方面卻擔心這樣的能量會影響人們的思考甚至被能量本身奴役。遊戲中有兩大主要陣營，這兩大互相爭奪主控權的全球性組織分別是「反抗軍」和「啟蒙軍」。「啟蒙軍」（Enlightened，以綠色標示）陣營希望能接納這股「神秘的能量XM」，並相信這股能量能賜予人類進步與改革，其追隨者相信神秘的能量會催生影響重大的「啟蒙運動」，使全人類進化。另一派「反抗軍」（Resistance，以藍色標示）陣營則奮力捍衛並守護僅存的人性，有些人認為他們對於變化或進步感到畏懼，但反抗軍堅信這一切都是為了保護人類。遊戲的玩家被稱為探員（Agent），兩個陣營互相角力，爭奪控制真實世界中的地標性建築或雕塑等Portal（譯作「能量塔」）。", img: "INGRESS"),
     ]
        Text("故事背景")
            .font(Font.system(size: 40))
            .foregroundColor(Color.white)
            .offset(y: -300)
        ForEach(data, id: \.str) { dataView in
           
            Image(dataView.img).resizable().frame(width: 400, height: 200)
                .offset(y: -150)
            Text(dataView.str).foregroundColor(Color.white)
                .padding(.horizontal)
                .offset(y: 170)
        }
    }
}
