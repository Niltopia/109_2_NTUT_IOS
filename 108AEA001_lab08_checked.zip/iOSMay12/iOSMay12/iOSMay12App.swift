//
//  iOSMay12App.swift
//  iOSMay12
//
//  Created by Vesper Lee on 2021/5/12.
//

import SwiftUI

@main
struct iOSMay12App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
