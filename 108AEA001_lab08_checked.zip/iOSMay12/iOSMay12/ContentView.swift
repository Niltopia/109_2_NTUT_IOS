//
//  ContentView.swift
//  iOSMay12
//
//  Created by Vesper Lee on 2021/5/12.
//

import SwiftUI

struct ContentView: View {
    var roles = ["頭文字D", "我和殭屍有個約會",  "無間道"]
    @State private var selectedIndex = 0
    @State private var age = 18
    @State private var showAlert = false
    @State private var strNote = ""
    @State private var birthDate = Date()
    @State var isFans = true
    @State private var scale: CGFloat = 1
    let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        return formatter
    }()
    var body: some View {
        VStack{
            Text("杜汶澤").font(.system(size: 40.0))
            Image("aab").resizable()
                .scaledToFit()
                .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/).blur(radius:scale)
            
            HStack {
                Stepper("年齡：\(age)", value: $age, in: 0...130)
            }
            Toggle(isOn: $isFans, label: {
                Text("是粉絲嗎？")
            })
            DatePicker(selection: $birthDate, in: ...Date(), displayedComponents: .date) {
                Text("生日")
                    .multilineTextAlignment(.trailing)
            }
            HStack {
                Text("喜歡程度")
                Slider(value: $scale, in: 1...5, step: 1, minimumValueLabel: Text("1"), maximumValueLabel: Text("5")) {
                    Text("age")
                }
            }
            HStack{
                Text("喜歡的電影/電視劇:")
                    .multilineTextAlignment(.trailing)
                Picker("喜歡的電影/電視劇:",selection: $selectedIndex) {
                    ForEach(roles.indices) { (index) in
                        Text(roles[index])
                    }
                }.frame(width:200,height: 100)
                .clipped()
            }
            TextField("口頭禪", text: $strNote)
            Button(action: {
                showAlert = true
            }, label: {
                Text("送出")
            }).alert(isPresented: $showAlert){
                () -> Alert in
                var answer = ""
                if (isFans){
                    answer += "我是「杜汶澤」的粉絲\n"
                }else{
                    answer += "我不是「杜汶澤」的粉絲\n"
                }
                answer += "年齡:"+String(age)+"\n生日:"
                answer += dateFormatter.string(from: birthDate)+"\n喜歡程度:"
                answer += scale.description
                answer += "\n喜歡的電影/電視劇:"+String(roles[selectedIndex])+"\n口頭禪:"+strNote+"\n"
                return Alert(title: Text("Important message"),message: Text(answer),dismissButton: .default(Text("Got it!")))
                
                
            }
        }.padding(.horizontal)
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
